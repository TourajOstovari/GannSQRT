﻿using System.Linq;

namespace GannGenerator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Welcome to Gann Generator !! 2024 / Mr. Touraj Ostovari");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("Maximum Number? ");
            Int64 max = Int64.Parse(Console.ReadLine());
            System.Collections.Generic.List<string> list = new List<string>();
            Console.ForegroundColor = ConsoleColor.Green;
            for (double i = 0; i <= max; i++)
            {
                if (Math.Sqrt(i) % 1 == 0)
                {
                    list.Add(i.ToString());
                    Console.WriteLine($"i: {i}");
                }
            }
            System.IO.File.WriteAllLinesAsync(@"D:\GANN_SQRT.Generation.txt", list);
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine(@"Saved List in Drive D:\");
        }
    }
}