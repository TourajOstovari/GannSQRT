namespace Gann
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Math.Sqrt(double.Parse(textBox1.Text)) % 1 == 0)
            {
                MessageBox.Show("YES!!! USE IN GANN .... ",":: GANN ::",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("NO!!! Not GANN NUMBER ::: ", ":: GANN ::", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}