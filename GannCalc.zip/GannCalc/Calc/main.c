#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    printf("Hello world! It's developed by Mr. Touraj Ostovari for Trading purpose. year 2024 \n");
    printf("Math Formulation Base:\t C2 = A2 + B2 - 2AB Cos C <<\n>> High - Low - High ///-\\\ Low - High - Low << In same or close trading period of time... <<\n");
    int a = 0, b = 0;
    printf("Enter A? \n");
    scanf("%d",&a);
    printf("Enter B? \n");
    scanf("%d",&b);
    int c_Angle =0;
    printf("Enter C? \n");
    scanf("%d",&c_Angle);
    float C = pow(a,2) + pow(b,2) - 2 * a * b * cos(c_Angle);
    printf("C is >> %f  SQRT (Rounded) is >> %f << Done! \nTime Series App\n",C,round(sqrt(C)));
    return 0;
}
